(function (root) {
    "use strict";

    /* istanbul ignore next */
    root.consts = root.consts || {};

    root.consts.initialLocation = "Av. Giuseppina Vianelli di Napoli, 1185, Campinas - SP";

    //root.consts.maphost = "http://localhost/proxy_googlemaps";
    //root.consts.maphost = "https://172.24.41.19:6443/proxy_googlemaps";
    root.consts.maphost = "https://taxi-ign.venturus.org.br:6443/proxy_googlemaps";

}(window));